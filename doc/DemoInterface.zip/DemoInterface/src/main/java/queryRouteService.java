import com.sf.integration.expressservice.service.CommonExpressServiceService;

import javax.xml.namespace.QName;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author SunQi
 * @Description:
 * @date Create in 2017/9/25 14:48
 */
public class queryRouteService {

    private RouteVo queryRoute(String mainnoId) {
        RouteVo routeVo = new RouteVo();
//        String uri = "http://bsp-ois.sit.sf-express.com:9080/bsp-ois/ws/sfexpressService?wsdl";  //WEBSERVICE 地址
//        String uri = "http://218.17.248.244:11080/bsp-oisp/ws/sfexpressService?wsdl";

        String uri = "http://bsp-oisp.sf-express.com/bsp-oisp/ws/sfexpressService?wsdl";
        String checkWord = "Ca5bvGScarYHwINuvk3Uem4smvagSyov";

        String xmlFile = "<Request service=\"RouteService\" lang=\"zh-CN\"> \n" +                //请求xml
                "  <Head>0251659966</Head>  \n" +
                "  <Body> \n" +
                "    <RouteRequest tracking_type=\"1\" method_type=\"1\" tracking_number=\"" + mainnoId +
                "\"/> \n" +
                "  </Body> \n" +
                "</Request>";
//        String checkWord = "j8DzkIFgmlomPt0aLuwU";       //密钥
//        String checkWord = "9OKu3lis4FIY";
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = com.sf.integration.expressservice.service.CommonExpressServiceService.class.getResource(".");
            url = new URL(baseUrl, uri);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        CommonExpressServiceService service = new CommonExpressServiceService(url,
                new QName("http://service.expressservice.integration.sf.com/", "CommonExpressServiceService"));

        //xml报文与checkWord前后连接
        String xc = xmlFile + checkWord;

        //MD5+base64编码
        String verifyCode = Util.md5EncryptAndBase64(xc);

        //请求返回
        String res = service.getCommonExpressServicePort().sfexpressService(xmlFile, verifyCode);
        System.out.println(res);


        return null;
    }


    public static void main(String[] args) {
        queryRouteService re = new queryRouteService();

        re.queryRoute("617233164588");
        re.queryRoute("617232431410");
        re.queryRoute("617233164649");

//        System.out.println(re.queryRoute("444001003588"));

    }

}
